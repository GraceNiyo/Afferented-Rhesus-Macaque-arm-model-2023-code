#!/usr/bin/env python3


'''
This code is used to run simulation with reflex gain scaled by the alpha drive to each muscle.
'''
from mujoco_py import load_model_from_path, MjSim, MjViewer
from scipy import signal
import numpy as np
import sys
import copy

class Model:
    def __init__(self, name):
        self.model = load_model_from_path(name)   # load the model from the path "name"
        self.sim = MjSim(self.model) # simulate the model
        self.initial_state = [-0.011,0.460,-0.111,0.348,-1.571]  # Define the initial arm posture 

    def get_model(self):
        return self.model   # access the loaded model 

    def get_sim(self):
        return self.sim    # access the simulation object 

    def get_init(self):
        return self.initial_state    # access the initial state 


class Controller:
    
    def __init__(self, model, seed=1,k = 0):  
        self.init_state = model.get_init()
        self.sim = model.get_sim()
        self.viewer = MjViewer(self.sim)
        self.k = k
        self.num_joint = len(self.sim.data.qpos)
        self.num_muscle = len(self.sim.data.ctrl)
        self.seed = seed
        self.log_stability_qpos = []
        self.log_stability_qvel = []
        self.log_stability_actuactor_length = []
        self.log_stability_actuactor_velocity = []
        self.log_xpos = []
        self.log_qpos = []
        self.log_qvel = []
        self.log_activation = []
        self.l0 = []
        self.log_actuator_length = []
        self.log_actuator_velocity = []
        self.log_actuator_force = []
        self.log_joint_torques = []
        self.signal = []
        

        fileName = '/home/niyog/Desktop/MacaqueArm_Codes/FeedforwardActivationData/alpha_ref_'+str(self.seed)+'.txt'
        with open(fileName) as f:
            lines = f.readlines()
            for i, l in enumerate(lines):
                l_list = l.split(" ")
                for j in range(self.num_muscle):
                    self.signal.append(float(l_list[j]))

        self.signal  = np.array(self.signal)
        l = int(len(self.signal)/(self.num_muscle))  
        self.signal  = self.signal.reshape(l,self.num_muscle)


    def run(self, simulation_period=8, stability_period = 1, fs = 2000):

        # init_checker = True
        stability_start  = 0
        stability_end    = stability_start + stability_period
        simulation_start = stability_end
        simulation_end   = simulation_start + simulation_period + (1/fs)
        muscle_activation =  self.signal
        start_index = 0

        Ia = np.zeros(self.num_muscle)
        alphaDrive = muscle_activation[start_index]  
        
        while True:

            sim_state = self.sim.get_state()
            self.sim.set_state(sim_state)


            if sim_state.time >= stability_start and sim_state.time < simulation_start:
                self.sim.data.qpos[:] = self.init_state[:]
              

            if sim_state.time>=simulation_start and sim_state.time<simulation_end:
                
                FeedForwardDrive = muscle_activation[start_index]
                # print("Descending command")
                # print(DescendCommand)

                if self.k != 0:

                    for i in range(self.num_muscle):
                        # print("alphaDrive used for feedback")
                        # print(alphaDrive)

                        if (self.sim.data.actuator_velocity[i] > 0):
                            Ia[i] = alphaDrive[i]*self.k* self.sim.data.actuator_velocity[i]  # alpha_gamma co_acativation 
                        else:
                            Ia[i]=0

                        alphaDrive= [(a_ref + Ia_afferent) for a_ref,Ia_afferent in zip(FeedForwardDrive,Ia)]  
                else:
                    alphaDrive = FeedForwardDrive   
                
                # print("alpha drive to activate muscle")
                # print(alphaDrive)

                self.sim.data.ctrl[:] = alphaDrive

                self.log_activation.append(alphaDrive)
                self.log_xpos.append(copy.deepcopy(self.sim.data.get_geom_xpos('hand')))
                start_index += 1

            # Render the simulation
           
            self.sim.step()
            self.viewer.render()
           
            if sim_state.time > simulation_end:
                print(start_index)
                break
      



        '''
        Write logs
        '''
              
        with open('log_activation_'+str(self.seed)+'_'+str(self.k)+'.txt', 'w') as f:
            print("Start to write log_activation")
            for l in self.log_activation:
                l = str(l)
                l = l.replace("[","")
                l = l.replace("]","")
                l = l.replace(",","")
                l = l.replace("\n","")
                f.write(l+'\n')
            # print("Finish to write")

        with open('log_xpos_'+str(self.seed)+'_'+str(self.k)+'.txt', 'w') as f:
    
            print("Start to write log_xpos")
            for l in self.log_xpos:
                l = str(l.tolist())
                l = l.replace("[","")
                l = l.replace("]","")
                l = l.replace(",","")
                l = l.replace("\n","")
                f.write(l+'\n')
            # print("Finish to write")



if __name__ == "__main__":

    # Load model file

    Path_to_model ="/home/niyog/Desktop/MacaqueArm_Codes/monkeyArm.xml" 
    model = Model(Path_to_model)
    
     # Give arm movement number (seed) and gain (k)model to controller (simulator)
    
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
        k = float(sys.argv[2])
        ctrl = Controller(model,seed,k)
    else:
        ctrl = Controller(model)
    ctrl.run(simulation_period= 8, stability_period = 1, fs=2000)  # define simulation period, stability period (wait time before sending activation)

