conda activate mujoco_py
for i in $(seq 1 1 2) #  number of arm movements to run 
do 
   
                    
            for k in $(seq 0 1 10) # reflex gain from 0: open-loop to maximal of 10 
            do     
                
                # Run ummodulated stretch reflexes or alpha-gamma co-activation
                # NOTE: MAKE SURE TO CHANGE LINE 100 OR 111 IN "Controller_UnmodulatedReflexGain_AlphaGammaCoAct.py" CODE ACCORDINGLY

                python3 Controller_UnmodulatedReflexGain_AlphaGammaCoAct.py $i $k 

                # To run Simulation for reflex gain scaled by alpha drive to the muscle replace line 12 by 15 below
                #python3 Controller_Reflex_Gain_Scaled_By_AlphaDrive.py $i $k   



                cp log_activation*   UnmodulatedReflexData/ActivationData/activation      # Change path to desired folder name for the data
                # cp log_activation*   AlphaGammaCoActData/ActivationData/activation
                # cp log_activation*   ScaledReflexGainData/ActivationData/activation

               
 

                cp log_xpos*  UnmodulatedReflexData/EndpointPositionData/xpos     
                # cp log_xpos*  AlphaGammaCoActData/EndpointPositionData/xpos        
                # cp log_xpos*  ScaledReflexGainData/EndpointPositionData/xpos  
                
        

                rm log* 
            done                                           
done
