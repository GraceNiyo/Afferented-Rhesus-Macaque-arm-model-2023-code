%% parameters
rng('default')
duration = 2; % seconds unit
fs = 2000;
t= 0:1/fs:duration;
NumMuscles = 25;
num_movement = 1100; % 1,100 arm movements 

%% genearate bimodal uniform distribution for maximal MVC

lowModeProb = 0.8;
% first mode
numSamplesMode1 = round(NumMuscles * lowModeProb);
mode1Min = 0.04;
mode1Max = 0.04;
mode1Samples = rand(num_movement,numSamplesMode1)*(mode1Max-mode1Min)+ mode1Min;

% second mode
numSamplesMode2 = NumMuscles - numSamplesMode1;
mode2Min = 0.6;
mode2Max = 0.6;
mode2Samples = rand(num_movement,numSamplesMode2)*(mode2Max-mode2Min)+ mode2Min;

maxMVC = [mode1Samples,mode2Samples];
figure
histogram(maxMVC(1,:),'Normalization','probability');
xlabel('Value');ylabel('Probability'); title('Bimodal uniform distribution')

%% generate activation signals 


actSig = zeros(length(t),NumMuscles);
actSig_scaled = zeros(length(t),NumMuscles);
actSig_ramp = zeros(length(t),NumMuscles);


for traj = 1

 a = randi([1 5],NumMuscles,1);
 b = randi([1 5],NumMuscles,1);

for m = 1:NumMuscles
    if a(m) == 1 || b(m) == 1
       a(m) =  a(m) + 1;
       b(m) = b(m) + 1;
    end 
actSig(:,m) = generalBetapdf(t,a(m),b(m));
end 


maxMVC_traj = maxMVC(traj,:);

maxMVC_perm = maxMVC_traj(randperm(NumMuscles));


for m =  1:NumMuscles
actSig_scaled(:,m) = rescale(actSig(:,m),0,maxMVC_perm(m));
[peak,idx] = max(actSig_scaled(:,m));
actSig_ramp(1:idx,m) = actSig_scaled(1:idx,m);
actSig_ramp(idx+1:end,m) = peak;
end
figure
subplot(1,2,1)
plot(actSig_scaled)
ylim([0 0.65])
subplot(1,2,2)
plot(actSig_ramp)
ylim([0 0.65])

 fileName = sprintf('/home/niyog/Desktop/MacaqueArm_Codes/FeedforwardActivationData/alpha_ref_%g.txt',traj);
 writematrix(actSig_ramp,fileName,'Delimiter',' ')

end 
